/**
 * Configuração da secção "Reservas".
 * As posições das mesas (x / y) são percentagens sobre a imagem /images/mapa-mesas.webp
 * (o mapa do design). Para pôr uma mesa fora de serviço, adicione o seu número a `blockedTables`.
 */
export type TableDef = { id: number; x: number; y: number };

/** Centro de cada mesa no mapa, em % da largura / altura da imagem. */
export const tables: TableDef[] = [
  { id: 1, x: 15.5, y: 20.4 },
  { id: 2, x: 28.2, y: 20.4 },
  { id: 3, x: 41.2, y: 20.4 },
  { id: 4, x: 54.4, y: 20.4 },
  { id: 5, x: 15.5, y: 35.2 },
  { id: 6, x: 28.2, y: 35.2 },
  { id: 7, x: 41.2, y: 35.2 },
  { id: 8, x: 53.6, y: 35.2 },
  { id: 9, x: 15.5, y: 51.4 },
  { id: 10, x: 28.2, y: 51.4 },
  { id: 11, x: 41.2, y: 51.4 },
  { id: 12, x: 54.4, y: 51.4 },
  { id: 13, x: 15.5, y: 67 },
  { id: 14, x: 28.2, y: 67 },
  { id: 15, x: 41.2, y: 67 },
  { id: 16, x: 54.4, y: 67 },
  { id: 17, x: 13.5, y: 83 },
  { id: 18, x: 27.2, y: 83 },
  { id: 19, x: 41.7, y: 83.2 },
  { id: 20, x: 57.4, y: 83 },
  { id: 21, x: 71.4, y: 83 },
];

/** Mesas fora de serviço (aparecem a cinzento, "Indisponível"). */
export const blockedTables: number[] = [];

export const seatsPerTable = 6;
export const maxPeople = 6;

/** Horário de reservas (como no design: 10:00 — 22:00), em intervalos de 30 min. */
export const openMinutes = 10 * 60;
export const closeMinutes = 22 * 60;
export const slotStep = 30;

/** Tempo durante o qual uma mesa reservada fica ocupada (min). */
export const stayMinutes = 120;

export const storageKey = "piripiri:reservas:v1";
