"use client";

import Image from "next/image";
import { useEffect, useMemo, useRef, useState, type FormEvent, type ReactNode } from "react";
import {
  ArrowRight,
  CalendarCheck,
  CalendarDays,
  Check,
  ChevronDown,
  Clock,
  MapPinned,
  Phone,
  Soup,
  User,
  Users,
  Utensils,
} from "lucide-react";
import Reveal from "./Reveal";
import { dishes } from "@/data/menu";
import {
  blockedTables,
  closeMinutes,
  maxPeople,
  openMinutes,
  seatsPerTable,
  slotStep,
  stayMinutes,
  storageKey,
  tables,
} from "@/data/reservas";
import { telHref, waLink } from "@/lib/site";

type Booking = {
  date: string; // yyyy-mm-dd
  time: string; // HH:MM
  table: number;
  people: number;
  name: string;
  phone: string;
  dish: string;
};
type Status = "available" | "reserved" | "unavailable";
type Errors = Partial<Record<"name" | "phone" | "date" | "time" | "table", string>>;

/* ---------- helpers ---------- */
const pad = (n: number) => String(n).padStart(2, "0");
const toMin = (t: string) => {
  const [h, m] = t.split(":").map(Number);
  return h * 60 + m;
};
const slots: string[] = [];
for (let m = openMinutes; m <= closeMinutes; m += slotStep) slots.push(`${pad(Math.floor(m / 60))}:${pad(m % 60)}`);

/** Hora actual em Maputo (UTC+2). */
function maputoNow() {
  const d = new Date(Date.now() + 2 * 3600 * 1000);
  return {
    today: d.toISOString().slice(0, 10),
    nowMin: d.getUTCHours() * 60 + d.getUTCMinutes(),
  };
}
const fmtDate = (iso: string) => iso.split("-").reverse().join("/");
const fmtPhone = (v: string) => {
  let d = v.replace(/\D/g, "");
  if (d.startsWith("258") && d.length > 9) d = d.slice(3);
  d = d.slice(0, 9);
  return [d.slice(0, 2), d.slice(2, 5), d.slice(5, 9)].filter(Boolean).join(" ");
};

/** Pratos do menu (carnes e peixe/marisco) para o campo "Tipo de Prato". */
const dishOptions = [
  ...dishes
    .filter((d) => d.cat === "Carnes" || d.cat === "Peixe & Marisco")
    .map((d) =>
      d.name === "Frango à Píri-píri" ? "Frango Inteiro" : d.name === "Frango à Píri-píri · Meio" ? "Meio Frango" : d.name
    ),
  "Decidir no local",
];

/* ---------- ícone de mesa (o mesmo do design, usado em 3 sítios) ---------- */
function TableIcon({ className = "h-5 w-5" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className={className} aria-hidden>
      <path d="M5 10h14M7 10v9M17 10v9M12 10v4" />
      <path d="M3 10h18" />
      <path d="M4 4h3v4M20 4h-3v4" />
    </svg>
  );
}

/* ---------- campos ---------- */
const fieldCls =
  "h-10 w-full rounded-lg border border-gold-400/55 bg-ink-800/90 px-3 text-[12.5px] text-cream outline-none transition placeholder:text-cream/35 focus:border-gold-300 focus:ring-1 focus:ring-gold-300 aria-[invalid=true]:border-flame-400";

function Field({ id, label, icon, error, children, className = "" }: { id: string; label: string; icon: ReactNode; error?: string; children: ReactNode; className?: string }) {
  return (
    <div className={className}>
      <label htmlFor={id} className="mb-1.5 flex items-center gap-2 text-[11px] font-medium text-cream">
        <span className="text-gold-400">{icon}</span>
        {label}
      </label>
      {children}
      {error && (
        <p id={`${id}-err`} role="alert" className="mt-1 text-[10.5px] text-flame-300">
          {error}
        </p>
      )}
    </div>
  );
}

function SelectWrap({ children }: { children: ReactNode }) {
  return (
    <div className="relative">
      {children}
      <ChevronDown className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gold-400" />
    </div>
  );
}

/* ---------- secção ---------- */
export default function Reservas() {
  const [clock, setClock] = useState({ today: "", nowMin: 0 });
  const [date, setDate] = useState("");
  const [time, setTime] = useState("19:00");
  const [people, setPeople] = useState(2);
  const [dish, setDish] = useState(dishOptions[0]);
  const [table, setTable] = useState<number | null>(1);
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [errors, setErrors] = useState<Errors>({});
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [done, setDone] = useState<Booking | null>(null);
  const formRef = useRef<HTMLFormElement>(null);

  /* relógio de Maputo + data por omissão (hoje) */
  useEffect(() => {
    const tick = () => setClock(maputoNow());
    tick();
    const id = setInterval(tick, 60000);
    return () => clearInterval(id);
  }, []);
  useEffect(() => {
    if (clock.today && !date) setDate(clock.today);
  }, [clock.today, date]);

  /* reservas guardadas neste dispositivo */
  useEffect(() => {
    try {
      const raw = localStorage.getItem(storageKey);
      if (raw) setBookings(JSON.parse(raw) as Booking[]);
    } catch {
      /* sem armazenamento disponível */
    }
  }, []);

  /* horários: no próprio dia, os que já passaram ficam desactivados */
  const slotDisabled = (s: string) => date === clock.today && toMin(s) <= clock.nowMin;
  const enabledSlots = slots.filter((s) => !slotDisabled(s));
  useEffect(() => {
    if (!date) return;
    if (time && slots.includes(time) && !slotDisabled(time)) return;
    setTime(enabledSlots.includes("19:00") ? "19:00" : enabledSlots[0] ?? "");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [date, clock.nowMin]);

  /* estado de cada mesa para a data/hora/nº de pessoas escolhidos */
  const reserved = useMemo(() => {
    const set = new Set<number>();
    if (!time) return set;
    for (const b of bookings) if (b.date === date && Math.abs(toMin(b.time) - toMin(time)) < stayMinutes) set.add(b.table);
    return set;
  }, [bookings, date, time]);

  const statusOf = (id: number): Status =>
    blockedTables.includes(id) || seatsPerTable < people ? "unavailable" : reserved.has(id) ? "reserved" : "available";

  const availableCount = tables.filter((t) => statusOf(t.id) === "available").length;

  /* se a mesa escolhida deixar de estar livre, passa para a primeira livre */
  useEffect(() => {
    if (table !== null && statusOf(table) === "available") return;
    const first = tables.find((t) => statusOf(t.id) === "available");
    setTable(first ? first.id : null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [reserved, people]);

  const pick = (id: number) => {
    if (statusOf(id) !== "available") return;
    setTable(id);
    setErrors((e) => ({ ...e, table: undefined }));
  };

  const validate = (): Errors => {
    const e: Errors = {};
    if (name.trim().length < 3) e.name = "Indique o seu nome completo.";
    if (!/^8[2-7]\d{7}$/.test(phone.replace(/\D/g, ""))) e.phone = "Número inválido. Ex.: 84 123 4567";
    if (!date || date < clock.today) e.date = "Escolha uma data a partir de hoje.";
    if (!time) e.time = "Sem horários livres neste dia.";
    if (table === null || statusOf(table) !== "available") e.table = "Escolha uma mesa disponível.";
    return e;
  };

  const submit = (ev: FormEvent) => {
    ev.preventDefault();
    const e = validate();
    setErrors(e);
    if (Object.keys(e).length) {
      const first = (["name", "phone", "date", "time", "table"] as const).find((k) => e[k]);
      if (first) formRef.current?.querySelector<HTMLElement>(`#res-${first}`)?.focus();
      return;
    }
    const booking: Booking = { date, time, table: table as number, people, name: name.trim(), phone, dish };
    const next = [...bookings, booking];
    setBookings(next);
    try {
      localStorage.setItem(storageKey, JSON.stringify(next));
    } catch {
      /* ignora */
    }
    setDone(booking);
    window.open(waLink(waMessage(booking)), "_blank", "noopener,noreferrer");
  };

  const reset = () => {
    setDone(null);
    setName("");
    setPhone("");
  };

  const selected = table;

  return (
    <section
      id="reservas"
      className="relative scroll-mt-20 overflow-hidden border-t border-cream/10 bg-ink-900 bg-[url('/images/bg/clean.webp')] bg-cover bg-center py-14 lg:py-16"
    >
      {/* frango na brasa, canto superior direito (como no design) */}
      <div aria-hidden className="pointer-events-none absolute right-0 top-0 h-[46%] w-full lg:h-[52%] lg:w-[64%]">
        <Image src="/images/bg/hero.webp" alt="" fill sizes="64vw" className="object-cover object-[75%_20%] opacity-90" />
        <div className="absolute inset-0 bg-gradient-to-r from-ink-900 via-ink-900/55 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-t from-ink-900 via-ink-900/40 to-transparent" />
      </div>

      <div className="container-x relative z-10">
        {/* título */}
        <div className="grid items-center gap-5 lg:grid-cols-[auto_1fr] lg:gap-8">
          <Reveal className="flex items-center gap-3 sm:gap-4">
            <TableIcon className="h-12 w-12 shrink-0 text-gold-400 sm:h-14 sm:w-14" />
            <h2 className="h-display text-[9.5vw] leading-[0.95] text-cream sm:text-[6vw] lg:text-[34px] xl:text-[40px]">
              Reserve a sua
              <span className="slant mt-1 block text-[1.55em] leading-[0.9] text-gold-400">mesa</span>
              <span className="mt-1 block text-[0.78em]">em poucos minutos</span>
            </h2>
          </Reveal>
          <Reveal delay={0.1} className="lg:border-l lg:border-cream/20 lg:pl-8">
            <p className="max-w-[330px] text-[14px] leading-relaxed text-cream/90">
              Escolha o prato que pretende, selecione a mesa e nós preparamos tudo para a sua chegada.
            </p>
            <span aria-hidden className="paint-r mt-3 block h-2 w-48 -rotate-2" />
          </Reveal>
        </div>

        {/* formulário + mapa */}
        <div className="mt-8 grid gap-5 lg:mt-10 lg:grid-cols-[0.96fr_1.04fr]">
          {/* ---- formulário ---- */}
          <Reveal>
            <div className="relative h-full rounded-[14px] border border-gold-400/70 bg-ink-900/85 p-5 backdrop-blur-sm sm:p-6">
              {done ? (
                <div className="flex h-full min-h-[360px] flex-col items-center justify-center text-center" role="status">
                  <span className="grid h-14 w-14 place-items-center rounded-full bg-gold-400 text-ink-900">
                    <Check className="h-7 w-7" strokeWidth={3} />
                  </span>
                  <h3 className="h-display mt-4 text-[26px] text-gold-400">Reserva registada</h3>
                  <p className="mt-3 max-w-[340px] text-[13px] leading-relaxed text-cream/85">
                    Mesa {done.table} para {done.people} {done.people === 1 ? "pessoa" : "pessoas"} no dia {fmtDate(done.date)} às{" "}
                    {done.time}. {done.dish === "Decidir no local" ? "" : `Prato: ${done.dish}.`}
                  </p>
                  <p className="mt-2 max-w-[340px] text-[12px] leading-relaxed text-cream/60">
                    Abrimos o WhatsApp com os dados da reserva. Envie a mensagem para o restaurante a confirmar.
                  </p>
                  <div className="mt-5 flex flex-wrap justify-center gap-3">
                    <a href={waLink(waMessage(done))} target="_blank" rel="noopener noreferrer" className="btn btn-gold !px-6 !py-3 !text-[11px]">
                      Enviar por WhatsApp
                    </a>
                    <button type="button" onClick={reset} className="btn btn-ghost !px-6 !py-3 !text-[11px]">
                      Nova reserva
                    </button>
                  </div>
                </div>
              ) : (
                <form ref={formRef} onSubmit={submit} noValidate className="grid grid-cols-1 gap-x-5 gap-y-4 sm:grid-cols-2">
                  <Field id="res-name" label="Nome Completo" icon={<User className="h-4 w-4" />} error={errors.name}>
                    <input
                      id="res-name"
                      type="text"
                      autoComplete="name"
                      placeholder="Ex: João da Silva"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      aria-invalid={!!errors.name}
                      aria-describedby={errors.name ? "res-name-err" : undefined}
                      className={fieldCls}
                    />
                  </Field>
                  <Field id="res-phone" label="Telefone" icon={<Phone className="h-4 w-4" />} error={errors.phone}>
                    <input
                      id="res-phone"
                      type="tel"
                      inputMode="tel"
                      autoComplete="tel-national"
                      placeholder="Ex: 84 123 4567"
                      value={phone}
                      onChange={(e) => setPhone(fmtPhone(e.target.value))}
                      aria-invalid={!!errors.phone}
                      aria-describedby={errors.phone ? "res-phone-err" : undefined}
                      className={fieldCls}
                    />
                  </Field>

                  <Field id="res-date" label="Data" icon={<CalendarDays className="h-4 w-4" />} error={errors.date}>
                    <input
                      id="res-date"
                      type="date"
                      min={clock.today || undefined}
                      value={date}
                      onChange={(e) => setDate(e.target.value)}
                      aria-invalid={!!errors.date}
                      aria-describedby={errors.date ? "res-date-err" : undefined}
                      className={`${fieldCls} [color-scheme:dark]`}
                    />
                  </Field>
                  <Field id="res-time" label="Horário" icon={<Clock className="h-4 w-4" />} error={errors.time}>
                    <SelectWrap>
                      <select
                        id="res-time"
                        value={time}
                        onChange={(e) => setTime(e.target.value)}
                        aria-invalid={!!errors.time}
                        aria-describedby={errors.time ? "res-time-err" : undefined}
                        className={`${fieldCls} appearance-none pr-9`}
                      >
                        {!time && <option value="">—</option>}
                        {slots.map((s) => (
                          <option key={s} value={s} disabled={slotDisabled(s)}>
                            {s}
                          </option>
                        ))}
                      </select>
                    </SelectWrap>
                  </Field>

                  <Field id="res-people" label="Nº de Pessoas" icon={<Users className="h-4 w-4" />}>
                    <SelectWrap>
                      <select id="res-people" value={people} onChange={(e) => setPeople(Number(e.target.value))} className={`${fieldCls} appearance-none pr-9`}>
                        {Array.from({ length: maxPeople }, (_, i) => i + 1).map((n) => (
                          <option key={n} value={n}>
                            {n} {n === 1 ? "Pessoa" : "Pessoas"}
                          </option>
                        ))}
                      </select>
                    </SelectWrap>
                  </Field>
                  <Field id="res-dish" label="Tipo de Prato" icon={<Utensils className="h-4 w-4" />}>
                    <SelectWrap>
                      <select id="res-dish" value={dish} onChange={(e) => setDish(e.target.value)} className={`${fieldCls} appearance-none pr-9`}>
                        {dishOptions.map((d) => (
                          <option key={d} value={d}>
                            {d}
                          </option>
                        ))}
                      </select>
                    </SelectWrap>
                  </Field>

                  <Field id="res-table" label="Escolha da Mesa" icon={<TableIcon className="h-4 w-4" />} error={errors.table} className="sm:col-span-2">
                    <SelectWrap>
                      <select
                        id="res-table"
                        value={table ?? ""}
                        onChange={(e) => pick(Number(e.target.value))}
                        aria-invalid={!!errors.table}
                        aria-describedby={errors.table ? "res-table-err" : undefined}
                        className={`${fieldCls} appearance-none pr-9`}
                      >
                        {table === null && <option value="">Sem mesas disponíveis</option>}
                        {tables.map((t) => {
                          const st = statusOf(t.id);
                          return (
                            <option key={t.id} value={t.id} disabled={st !== "available"}>
                              Mesa {t.id}
                              {st === "reserved" ? " — reservada" : st === "unavailable" ? " — indisponível" : ""}
                            </option>
                          );
                        })}
                      </select>
                    </SelectWrap>
                  </Field>

                  <div className="mt-2 flex justify-center sm:col-span-2">
                    <button type="submit" className="btn btn-fire !px-9 !py-4 !text-[12px]">
                      <CalendarCheck className="h-5 w-5" />
                      Confirmar reserva
                      <ArrowRight className="h-4 w-4" />
                    </button>
                  </div>
                </form>
              )}
            </div>
          </Reveal>

          {/* ---- mapa das mesas ---- */}
          <Reveal delay={0.08}>
            <div className="h-full rounded-[14px] border border-gold-400/70 bg-ink-900/85 p-4 backdrop-blur-sm sm:p-5">
              <div className="mb-3 flex items-center gap-3">
                <MapPinned className="h-8 w-8 text-gold-400" strokeWidth={1.6} />
                <div>
                  <h3 className="h-display slant text-[22px] leading-none text-gold-400 sm:text-[26px]">Mapa das mesas</h3>
                  <span aria-hidden className="paint-r mt-1 block h-1.5 w-40 -rotate-1" />
                </div>
              </div>

              <div className="grid items-start gap-3 sm:grid-cols-[1fr_auto]">
                <div
                  className="relative overflow-hidden rounded-[8px] border border-gold-400/40"
                  style={{ containerType: "inline-size" }}
                >
                  <Image
                    src="/images/mapa-mesas.webp"
                    alt="Planta da sala do Restaurante Píri Píri com as mesas numeradas de 1 a 21"
                    width={432}
                    height={380}
                    sizes="(max-width: 640px) 92vw, (max-width: 1024px) 60vw, 460px"
                    className="block h-auto w-full select-none"
                    draggable={false}
                  />
                  {tables.map((t) => {
                    const st = statusOf(t.id);
                    const isSel = selected === t.id;
                    return (
                      <button
                        key={t.id}
                        type="button"
                        onClick={() => pick(t.id)}
                        disabled={st !== "available"}
                        aria-pressed={isSel}
                        aria-label={`Mesa ${t.id}${st === "reserved" ? ", reservada" : st === "unavailable" ? ", indisponível" : isSel ? ", seleccionada" : ""}`}
                        style={{ left: `${t.x}%`, top: `${t.y}%`, fontSize: "2.7cqw" }}
                        className={`group absolute grid aspect-square w-[12%] -translate-x-1/2 -translate-y-1/2 place-items-center rounded-[14%] outline-none transition focus-visible:ring-2 focus-visible:ring-gold-300 ${
                          isSel
                            ? "bg-gold-400/45 shadow-[0_0_22px_7px_rgba(255,190,20,0.55)] ring-1 ring-gold-300"
                            : st === "available"
                              ? "hover:bg-gold-400/20"
                              : "cursor-not-allowed bg-ink-900/45"
                        }`}
                      >
                        <span
                          className={`grid aspect-square w-[46%] place-items-center rounded-full border-2 font-bold leading-none transition-transform group-hover:scale-110 ${
                            st === "reserved"
                              ? "border-flame-400 bg-flame-500 text-white"
                              : st === "unavailable"
                                ? "border-zinc-400 bg-zinc-600 text-zinc-200"
                                : isSel
                                  ? "border-gold-300 bg-ink-900 text-gold-300"
                                  : "border-gold-400 bg-ink-900 text-white"
                          }`}
                        >
                          {t.id}
                        </span>
                      </button>
                    );
                  })}
                </div>

                <div className="grid gap-3 sm:w-[132px]">
                  <ul className="grid gap-2.5 rounded-[10px] border border-gold-400/30 bg-ink-800/80 p-3 text-[11px] text-cream sm:gap-3.5">
                    <li className="flex items-center gap-2.5">
                      <span className="h-4 w-4 shrink-0 rounded-full bg-gold-400" /> Mesa Disponível
                    </li>
                    <li className="flex items-center gap-2.5">
                      <span className="h-4 w-4 shrink-0 rounded-full bg-flame-400" /> Mesa Reservada
                    </li>
                    <li className="flex items-center gap-2.5">
                      <span className="h-4 w-4 shrink-0 rounded-full bg-zinc-500" /> Mesa Indisponível
                    </li>
                  </ul>
                  <div className="rounded-[10px] border border-gold-400/30 bg-ink-800/80 p-2.5 text-center">
                    <p className="text-[13px] font-extrabold text-gold-400">{selected ? `Mesa ${selected}` : "Sem mesa"}</p>
                    <div className="relative mt-2 aspect-[4/3] overflow-hidden rounded-md border border-gold-400/30 sm:aspect-[1/1]">
                      <Image
                        src="/images/interior.jpg"
                        alt={selected ? `Ambiente junto à mesa ${selected}` : "Sala do restaurante"}
                        fill
                        sizes="132px"
                        className="object-cover object-[62%_80%] photo-grade"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </Reveal>
        </div>

        {/* faixa informativa */}
        <Reveal delay={0.1}>
          <ul className="mx-auto mt-8 grid max-w-[1000px] items-center gap-6 text-center sm:grid-cols-3 sm:gap-0 sm:text-left">
            <li className="flex items-center justify-center gap-4 sm:px-6">
              <span className="grid h-14 w-14 shrink-0 place-items-center rounded-full border-2 border-gold-400 text-gold-400">
                <Clock className="h-7 w-7" />
              </span>
              <div>
                <p className="text-[12px] text-cream/90">Horário de Reservas</p>
                <p className="font-display text-[22px] leading-tight tracking-wide text-gold-400">10:00 — 22:00</p>
              </div>
            </li>
            <li className="flex items-center justify-center gap-4 sm:border-x sm:border-cream/15 sm:px-6">
              <span className="grid h-14 w-14 shrink-0 place-items-center rounded-full border-2 border-gold-400 text-gold-400">
                <TableIcon className="h-7 w-7" />
              </span>
              <div>
                <p className="text-[14px] font-bold text-cream">
                  {availableCount} {availableCount === 1 ? "Mesa Disponível" : "Mesas Disponíveis"}
                </p>
                <p className="text-[11px] text-cream/70">(Capacidade para várias pessoas)</p>
              </div>
            </li>
            <li className="flex items-center justify-center gap-4 sm:px-6">
              <span className="grid h-14 w-14 shrink-0 place-items-center text-gold-400">
                <Soup className="h-10 w-10" strokeWidth={1.5} />
              </span>
              <p className="max-w-[230px] text-[12.5px] leading-snug text-cream/90">
                O prato escolhido será preparado antes da sua chegada.
              </p>
            </li>
          </ul>
          <p className="mt-5 text-center text-[11px] text-cream/50">
            Prefere reservar por telefone?{" "}
            <a href={telHref} className="font-semibold text-gold-300 hover:text-gold-200">
              84 672 4350
            </a>
          </p>
        </Reveal>
      </div>
    </section>
  );
}

function waMessage(b: Booking) {
  return [
    "Olá Piri Piri! Gostaria de reservar uma mesa.",
    "",
    `Nome: ${b.name}`,
    `Telefone: ${b.phone}`,
    `Data: ${fmtDate(b.date)}`,
    `Horário: ${b.time}`,
    `Pessoas: ${b.people}`,
    `Mesa: ${b.table}`,
    `Prato: ${b.dish}`,
  ].join("\n");
}
